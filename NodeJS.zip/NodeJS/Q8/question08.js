var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'dilojan36@gmail.com',
    pass: 'dilomac1234'
  }
});

var mailOptions = {
  from: 'dilojan36@gmail.com',
  to: 'k.tharusan@gmail.com',
  subject: 'Testing my nodemailer module',
  text: 'This is easy !'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
